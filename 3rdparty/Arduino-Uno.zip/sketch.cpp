#include <Arduino.h>
 
 void setup()
 {
	// Preparing board
 }
 
 void loop()
 {
	// Board routine
 }