/*
 * $projectname$.h
 *
 * Created: $time$
 *  Author: $username$
 */

#ifndef LIBRARY_H
#define LIBRARY_H

#include <Arduino.h>

/*! Doxygen documentation about class $projectname$
 @brief ... brief desc of $projectname$. */
class $projectname$
{
public:
  /** @name Constructors */
  //!@{
  /*! Basic constructor. */
  $projectname$();
  //!@}

private:
  //private member variables
  //private methods
};



#endif //LIBRARY_H