/*
 * $projectname$.cpp
 *
 * Created: $time$
 *  Author: $username$
 */

#include <avr/io.h>

#inlude $projectname$.h

//constructor
$projectname$::$projectname$()
{
}